-- haucs_bridge.lua  --  083026
--
-- Re-emits the Pi's NAMED_VALUE_FLOAT messages from the autopilot itself.
--
-- Why this exists: the Pi sends HAUCS / WVOLT / WAMP / WPKA as
-- MAV_COMP_ID_ONBOARD_COMPUTER (191), because sending as component 1 is
-- rejected by the Cube as a routing loop. Mission Planner appears to file
-- named floats per component, so fields from 191 do not reach the Quick tab
-- or the HUD user-item list, which read component 1. This script receives
-- them on the FC and re-sends them with gcs:send_named_float(), which emits
-- as component 1 -- the same path payload.lua's p_DO already takes.
--
-- Nothing changes on the Pi. It keeps sending as 191; the Cube echoes as 1.
--
-- ---------------------------------------------------------------------------
-- COEXISTENCE with RC7_to_RTL.lua, payload.lua and lights.lua
--
-- All scripts share ONE Lua state, so every global is shared. That is what
-- broke RC7 RTL when two scripts both defined a global `update`. Everything
-- here is `local`, and the update function is named haucs_bridge_update, which
-- does not appear in any of the other three.
--
-- This script also calls mavlink:init(). That is a process-wide singleton, so
-- only ONE script may call it. None of the other three touch mavlink, so this
-- is safe today -- but do not add a second script that calls mavlink:init().
--
-- Adding a fourth script may need more scripting heap. If the console shows
-- "scripting: out of memory" or scripts stop loading, raise SCR_HEAP_SIZE
-- (try 200000) and reboot.
-- ---------------------------------------------------------------------------

local MAV_SEVERITY_INFO    = 6
local MAV_SEVERITY_WARNING = 4

local MSGID_NAMED_VALUE_FLOAT = 251

-- Wire layout of NAMED_VALUE_FLOAT. MAVLink orders fields by size, largest
-- first, NOT by declaration order:
--     time_boot_ms  uint32   4
--     value         float    4
--     name          char[10] 10
local NVF_FMT = '<I4fc10'
local NVF_LEN = 18

local RUN_INTERVAL_MS = 100    -- 10 Hz; the Pi sends ~7 msg/s total
local MAX_PER_TICK    = 8      -- bound the work per scheduler slice
local MIN_GAP_MS      = 150    -- per-name resend floor, see loop guard below

-- Only these are re-emitted. Anything else on 251 is ignored, so this cannot
-- accidentally duplicate p_DO / p_temp / p_pres from payload.lua.
local FORWARD = {
    HAUCS = true,
    WVOLT = true,
    WAMP  = true,
    WPKA  = true,
}

local last_sent = {}      -- name -> millis() of last re-emit
local n_fwd     = 0
local n_bad     = 0
local started   = false

-- ---------------------------------------------------------------------------
-- Startup. Guarded, because a firmware built without the MAVLink scripting
-- bindings has no `mavlink` singleton, and indexing nil is a hard error that
-- would take down the whole Lua state -- and with it payload.lua, the RC7 RTL
-- handler and the lights.
-- ---------------------------------------------------------------------------
local function bridge_start()
    if mavlink == nil then
        gcs:send_text(MAV_SEVERITY_WARNING,
                      'haucs_bridge: no mavlink bindings in this firmware')
        return false
    end

    -- 083026: argument order is mavlink:init(buffer_depth, num_rx_msgid) on
    -- ArduCopter V4.6.0 -- buffer FIRST, id count SECOND. An earlier draft of
    -- this file had it the other way round, which would have registered a
    -- 10-entry id table served by a 1-deep queue: registration succeeds, then
    -- the queue overflows continuously at the Pi's ~7 msg/s and fields flicker
    -- rather than failing cleanly.
    --   10 = queue depth, comfortable against 7 msg/s at a 10 Hz drain
    --    1 = we register exactly one msgid, NAMED_VALUE_FLOAT
    local ok = pcall(function()
        mavlink:init(10, 1)
        mavlink:register_rx_msgid(MSGID_NAMED_VALUE_FLOAT)
    end)
    if not ok then
        gcs:send_text(MAV_SEVERITY_WARNING,
                      'haucs_bridge: mavlink init failed, check init() args')
        return false
    end
    return true
end

-- ---------------------------------------------------------------------------
local function handle_one(msg)
    if type(msg) ~= 'string' then
        n_bad = n_bad + 1
        return
    end

    -- MAVLink 2 truncates trailing zero bytes, so a short name arrives with
    -- the padding stripped and the payload is shorter than 18. Pad it back or
    -- string.unpack raises "data string too short".
    if #msg < NVF_LEN then
        msg = msg .. string.rep('\0', NVF_LEN - #msg)
    end

    local ok, _, value, raw = pcall(string.unpack, NVF_FMT, msg)
    if not ok then
        n_bad = n_bad + 1
        return
    end

    -- char[10] is NUL padded; keep only what precedes the first NUL.
    local name = string.match(raw, '^[^%z]*')
    if not FORWARD[name] then
        return
    end

    -- Loop guard. gcs:send_named_float() goes to the GCS transmit path and is
    -- not fed back into scripting, so a loop should be impossible -- but if a
    -- future firmware ever did echo it, an unbounded bridge would amplify
    -- without limit. This floor makes that harmless instead of fatal.
    local now = millis()
    local prev = last_sent[name]
    if prev ~= nil and (now - prev) < MIN_GAP_MS then
        return
    end
    last_sent[name] = now

    gcs:send_named_float(name, value)
    n_fwd = n_fwd + 1
end

-- ---------------------------------------------------------------------------
local function haucs_bridge_update()
    if not started then
        return haucs_bridge_update, 1000    -- idle slowly, never busy-loop
    end

    local n = 0
    while n < MAX_PER_TICK do
        local msg = mavlink:receive_chan()
        if msg == nil then
            break
        end
        handle_one(msg)
        n = n + 1
    end

    return haucs_bridge_update, RUN_INTERVAL_MS
end

-- ---------------------------------------------------------------------------
started = bridge_start()
if started then
    gcs:send_text(MAV_SEVERITY_INFO,
                  'haucs_bridge: active, re-emitting HAUCS/WVOLT/WAMP/WPKA')
else
    gcs:send_text(MAV_SEVERITY_INFO,
                  'haucs_bridge: inactive, other scripts unaffected')
end

-- Returning the function rather than calling it means nothing runs during FC
-- init -- the same correction made to RC7_to_RTL.lua on 082426.
return haucs_bridge_update, RUN_INTERVAL_MS
