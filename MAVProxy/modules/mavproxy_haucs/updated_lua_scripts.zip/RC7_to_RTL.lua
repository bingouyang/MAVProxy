local RC_CH = 7
local HIGH_PWM = 1800
local RTL_MODE = 6

local last_high = false

-- 082426: was a GLOBAL `update`. payload.lua defines the same global, so
-- whichever loaded second won and this script's `return update, 100` then
-- rescheduled the OTHER script's function. RC7 RTL stopped working after
-- one tick. `local function` gives each script its own name.
local function rc7_rtl_update()
    local pwm = rc:get_pwm(RC_CH)

    if pwm then
        local high = pwm > HIGH_PWM

        -- rising edge: button was just pressed
        if high and not last_high then
            gcs:send_text(6, "RC7 pressed: switching to RTL")
            vehicle:set_mode(RTL_MODE)
        end

        last_high = high
    end

    return rc7_rtl_update, 100
end

-- 082426: was `return update()`, which runs one iteration immediately at
-- load. Returning the function instead lets the scheduler make the first
-- call, so nothing executes during FC init.
return rc7_rtl_update, 100