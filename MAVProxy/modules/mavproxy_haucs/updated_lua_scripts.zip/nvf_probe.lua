-- nvf_probe.lua  --  083026   TEMPORARY TEST SCRIPT, REMOVE AFTER USE
--
-- Answers one question: does Mission Planner's Quick tab / HUD user-item list
-- show NAMED_VALUE_FLOAT fields that arrive from COMPONENT 1?
--
-- The Pi sends HAUCS / WVOLT / WAMP / WPKA as component 191 and they do not
-- appear in that list. The theory is that MP files named floats per component
-- and the list reads component 1. gcs:send_named_float() emits as component 1,
-- so if these show up, the theory holds and haucs_bridge.lua will fix it.
--
-- payload.lua cannot be used for this test on an airframe with no I2C sensors:
-- its reads return nil, every guard fails, and it sends nothing at all. That
-- would look like a negative result when it is really just no data.
--
-- No hardware required. Values are constants chosen to be obviously fake.
--
-- HOW TO READ THE RESULT, after a reboot with this loaded:
--   p_DO and PROBE both appear in the Quick dropdown
--       -> component 1 is what the list shows. Theory confirmed.
--          Delete this file, install haucs_bridge.lua.
--   neither appears
--       -> the Quick dropdown does not show named floats in this MP version.
--          The bridge will not help. Try the HUD's User Items dialog instead
--          (right-click the HUD); that is a different list.
--
-- Coexistence: all locals, and nvf_probe_update collides with nothing in
-- payload.lua (payload_update), RC7_to_RTL.lua (rc7_rtl_update) or lights.lua
-- (update_LEDs). Does not touch mavlink, so it is safe to run alongside
-- haucs_bridge.lua too, though there is no reason to.

local MAV_SEVERITY_INFO = 6
local RUN_INTERVAL_MS   = 1000

local tick = 0

local function nvf_probe_update()
    tick = tick + 1

    -- p_DO: the name you have seen in the Quick list before, so it is the
    -- control. If this one does not appear, the problem is not the component.
    gcs:send_named_float('p_DO', 15.82)

    -- PROBE: a fresh name MP has never seen, ramping so it is obvious it is
    -- live rather than a stale cached value.
    gcs:send_named_float('PROBE', tick % 100)

    return nvf_probe_update, RUN_INTERVAL_MS
end

gcs:send_text(MAV_SEVERITY_INFO,
              'nvf_probe: sending p_DO and PROBE from component 1')

return nvf_probe_update, RUN_INTERVAL_MS
